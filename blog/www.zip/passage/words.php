<br><br><br><br>
<ul style="list-style:none">
<li>Mama take this badge from me</li>
<li>I can't use it anymore</li>
<li>IIt's getting dark too dark to see</li>
<li>IFeels like I'm knockin' on heaven's door</li>
<li>IKnock-knock-knockin' on heaven's door</li>
<li>IKnock-knock-knockin' on heaven's door</li>
<li>IKnock-knock-knockin' on heaven's door</li>
<li>IKnock-knock-knockin' on heaven's door</li>
<li>IMama put my guns in the ground</li>
<li>II can't shoot them anymore</li>
<li>IThat cold black cloud is comin' down</li>
<li>IFeels like I'm knockin' on heaven's door</li>
<li>IKnock-knock-knockin' on heaven's door</li>
<li>IKnock-knock-knockin' on heaven's door</li>
<li>IKnock-knock-knockin' on heaven's door</li>
<li>IKnock-knock-knockin' on heaven's door</li>
</ul>