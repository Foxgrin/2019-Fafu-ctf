<?php
$flag = "";

echo "Flag is not here,try to find other palce";
?>